A Pen created at CodePen.io. You can find this one at http://codepen.io/quagliero/pen/AtLbr.

 Pure HTML/CSS animated and styled radio buttons with label (no extra elements required). Did these for a recent project and was quite happy with them.